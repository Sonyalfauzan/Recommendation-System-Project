# Laporan Proyek Machine Learning - Sistem Rekomendasi Film

## Project Overview

Proyek ini bertujuan untuk mengembangkan sistem rekomendasi film menggunakan dataset MovieLens 100K. Sistem rekomendasi film sangat penting dalam industri hiburan modern karena dapat membantu pengguna menemukan konten yang relevan di tengah banjir informasi, meningkatkan pengalaman pengguna, dan berpotensi meningkatkan pendapatan platform streaming atau bioskop.

Menurut penelitian oleh Gomez-Uribe dan Hunt (2015)[1], sistem rekomendasi yang efektif dapat meningkatkan retensi pelanggan hingga 50% dan meningkatkan penjualan hingga 30%. Oleh karena itu, pengembangan sistem rekomendasi film yang akurat dan efektif menjadi sangat penting bagi industri hiburan.

## Business Understanding

### Problem Statements

1. Bagaimana cara merekomendasikan film kepada pengguna berdasarkan kemiripan konten film?
2. Bagaimana cara merekomendasikan film kepada pengguna berdasarkan pola peringkat dari pengguna lain?
3. Bagaimana mengukur kinerja sistem rekomendasi yang dikembangkan?

### Goals

1. Mengembangkan sistem rekomendasi berbasis konten (content-based filtering) yang dapat merekomendasikan film berdasarkan kemiripan genre.
2. Mengembangkan sistem rekomendasi kolaboratif (collaborative filtering) yang dapat merekomendasikan film berdasarkan pola peringkat pengguna.
3. Mengevaluasi kinerja sistem rekomendasi menggunakan metrik yang sesuai.

### Solution Statements

1. Menggunakan teknik TF-IDF dan cosine similarity untuk mengembangkan sistem rekomendasi berbasis konten.
2. Mengimplementasikan algoritma SVD (Singular Value Decomposition) untuk sistem rekomendasi kolaboratif.
3. Mengevaluasi sistem rekomendasi berbasis konten menggunakan metrik precision@k.
4. Mengevaluasi sistem rekomendasi kolaboratif menggunakan metrik RMSE (Root Mean Square Error) dan MAE (Mean Absolute Error).

## Data Understanding

Dataset yang digunakan dalam proyek ini adalah MovieLens 100K, yang berisi 100.000 peringkat dari 943 pengguna pada 1.682 film. Dataset ini terdiri dari dua file utama:

1. u.item: Informasi film (movie_id, title, release_date, genres)
2. u.data: Data peringkat (user_id, movie_id, rating, timestamp)

### Exploratory Data Analysis (EDA)

Setelah melakukan analisis awal pada dataset, berikut beberapa insight yang diperoleh:

1. Distribusi Rating:
   
   | Rating | Count | Percentage |
   |--------|-------|------------|
   | 1      | 6110  | 6.11%      |
   | 2      | 11370 | 11.37%     |
   | 3      | 27145 | 27.15%     |
   | 4      | 34174 | 34.17%     |
   | 5      | 21201 | 21.20%     |

   Insight: Mayoritas rating berada pada skala 3-4, menunjukkan kecenderungan pengguna untuk memberikan penilaian positif.

2. Top 10 Film dengan Rating Tertinggi (minimal 100 rating):

   | Title                                   | Average Rating | Number of Ratings |
   |-----------------------------------------|----------------|-------------------|
   | The Shawshank Redemption (1994)         | 4.52           | 172               |
   | Schindler's List (1993)                 | 4.47           | 298               |
   | Casablanca (1942)                       | 4.45           | 243               |
   | Rear Window (1954)                      | 4.39           | 209               |
   | Star Wars: Episode IV - A New Hope (1977)| 4.36           | 583               |
   | 12 Angry Men (1957)                     | 4.35           | 125               |
   | The Usual Suspects (1995)               | 4.34           | 267               |
   | Citizen Kane (1941)                     | 4.33           | 198               |
   | To Kill a Mockingbird (1962)            | 4.32           | 219               |
   | One Flew Over the Cuckoo's Nest (1975)  | 4.30           | 264               |

   Insight: Film-film klasik dan drama mendominasi daftar film dengan rating tertinggi, menunjukkan preferensi pengguna terhadap film-film berkualitas tinggi dan berpengaruh.

3. Distribusi Genre:

   ![picture 0](https://i.imgur.com/bbqnxwU.png)  


   Insight: Genre Drama, Comedy, dan Action adalah yang paling banyak muncul dalam dataset. Ini menunjukkan bahwa ketiga genre tersebut paling populer di kalangan pengguna.

Visualisasi dan insight ini memberikan pemahaman yang lebih baik tentang karakteristik dataset dan preferensi pengguna, yang akan membantu dalam pengembangan sistem rekomendasi.

## Data Preparation

Beberapa tahap persiapan data yang dilakukan:

1. Penggabungan genre film menjadi satu kolom string:
   Hal ini dilakukan untuk memudahkan proses TF-IDF pada tahap pemodelan content-based filtering. Dengan menggabungkan genre menjadi satu string, kita dapat menangkap informasi genre secara lebih efisien.

2. Penggabungan data film dan peringkat:
   Penggabungan ini diperlukan untuk analisis lebih lanjut dan persiapan data untuk collaborative filtering. Dengan menggabungkan kedua dataset, kita memiliki informasi lengkap tentang film, genre, dan rating dalam satu tabel.

3. Pemisahan data menjadi set pelatihan dan pengujian untuk collaborative filtering:
   Pemisahan ini penting untuk evaluasi model collaborative filtering. Dengan memisahkan data menjadi set pelatihan dan pengujian, kita dapat menilai kemampuan model dalam memprediksi rating yang belum pernah dilihat sebelumnya.

4. TF-IDF (Term Frequency-Inverse Document Frequency):
   TF-IDF adalah teknik pemrosesan teks yang digunakan untuk mengubah string genre menjadi vektor numerik. Proses ini terdiri dari dua komponen:

   - TF (Term Frequency): Menghitung frekuensi kemunculan setiap term (dalam hal ini, genre) dalam sebuah dokumen (film).
   - IDF (Inverse Document Frequency): Mengukur kepentingan sebuah term dalam seluruh korpus (seluruh dataset film).

   TF-IDF memberikan bobot yang lebih tinggi pada genre yang jarang muncul dalam keseluruhan dataset, sehingga dapat menangkap karakteristik unik dari setiap film. Misalnya, genre yang umum seperti "Drama" akan memiliki bobot IDF yang lebih rendah dibandingkan genre yang lebih jarang seperti "Film-Noir".

   Dalam konteks sistem rekomendasi film, TF-IDF membantu kita mengidentifikasi genre yang paling diskriminatif untuk setiap film, yang kemudian akan digunakan dalam perhitungan kemiripan antar film.

## Modeling

### Content-based Filtering menggunakan Cosine Similarity

Cara kerja:
1. TF-IDF (Term Frequency-Inverse Document Frequency) digunakan untuk mengubah string genre menjadi vektor numerik. TF-IDF memberikan bobot yang lebih tinggi pada genre yang jarang muncul, sehingga dapat menangkap karakteristik unik dari setiap film.

2. Cosine similarity dihitung antara vektor TF-IDF dari semua pasangan film. Cosine similarity mengukur sudut antara dua vektor dalam ruang multidimensi, memberikan nilai antara 0 (tidak mirip sama sekali) hingga 1 (identik).

3. Dalam konteks sistem rekomendasi film, cosine similarity membantu menemukan film-film yang memiliki kombinasi genre paling mirip. Misalnya, jika film A memiliki genre "Action, Adventure, Sci-Fi" dan film B memiliki genre "Action, Sci-Fi, Thriller", cosine similarity akan memberikan nilai yang tinggi karena kedua film berbagi dua genre yang sama (Action dan Sci-Fi).

4. Fungsi `get_content_based_recommendations` bekerja dengan cara:
   - Mencari indeks film input dalam dataset.
   - Menghitung cosine similarity antara film input dengan semua film lain.
   - Mengurutkan film-film berdasarkan nilai similarity dari tertinggi ke terendah.
   - Mengambil 10 film teratas (tidak termasuk film input itu sendiri) sebagai rekomendasi.

Parameter utama:
- stop_words='english' pada TfidfVectorizer: Menghilangkan kata-kata umum dalam bahasa Inggris yang tidak memberikan informasi signifikan.

Kelebihan:
- Dapat merekomendasikan item baru tanpa data peringkat.
- Mampu menangkap karakteristik spesifik item berdasarkan fitur.

Kekurangan:
- Terbatas pada fitur yang didefinisikan, sulit menangkap preferensi kompleks.
- Cenderung merekomendasikan item yang sangat mirip, kurang dalam keragaman.

Top-5 rekomendasi untuk film "Toy Story (1995)":
1. "Aladdin (1992)"
2. "The Lion King (1994)"
3. "Pocahontas (1995)"
4. "Beauty and the Beast (1991)"
5. "The Little Mermaid (1989)"

Insight: Rekomendasi menunjukkan film-film animasi keluarga yang populer pada era yang sama, menandakan bahwa model berhasil menangkap kemiripan genre dan karakteristik film.

### Collaborative Filtering menggunakan SVD (Singular Value Decomposition)

Cara kerja:
1. SVD (Singular Value Decomposition) adalah teknik dekomposisi matriks yang sangat umum digunakan dalam banyak bidang, termasuk sistem rekomendasi. SVD memecah matriks user-item menjadi tiga matriks: U (user features), Σ (singular values), dan V^T (item features).

2. Dalam konteks sistem rekomendasi:
   - Matriks U merepresentasikan pengguna dalam ruang laten.
   - Matriks V^T merepresentasikan item (film) dalam ruang laten yang sama.
   - Matriks Σ menunjukkan kekuatan atau kepentingan setiap faktor laten.

3. Model mempelajari representasi laten dari user dan item dalam ruang berdimensi lebih rendah. Ini memungkinkan model untuk menangkap pola tersembunyi dalam data rating.

4. Prediksi rating dilakukan dengan mengalikan representasi user dan item yang telah dipelajari.

5. Fungsi `get_collaborative_recommendations` bekerja dengan cara:
   - Mengidentifikasi film-film yang belum dinilai oleh pengguna target.
   - Memprediksi rating untuk semua film yang belum dinilai menggunakan model SVD.
   - Mengurutkan film-film berdasarkan prediksi rating dari tertinggi ke terendah.
   - Mengambil 10 film teratas sebagai rekomendasi.

Parameter utama:
- n_factors=100: Jumlah faktor laten yang digunakan. Menentukan kompleksitas model dan kemampuannya menangkap pola dalam data.
- n_epochs=20: Jumlah iterasi pelatihan. Lebih banyak epoch dapat meningkatkan akurasi tetapi juga meningkatkan waktu komputasi.
- lr_all=0.005: Learning rate untuk semua parameter. Mengontrol seberapa besar update parameter pada setiap iterasi.
- reg_all=0.02: Regularization term untuk mencegah overfitting. Membantu model generalisasi lebih baik ke data yang belum pernah dilihat.

Kelebihan:
- Dapat menangkap pola preferensi kompleks yang tidak terlihat.
- Mampu memberikan rekomendasi personal berdasarkan perilaku kolektif pengguna.

Kekurangan:
- Membutuhkan data peringkat yang cukup.
- Sulit menangani item baru (cold start problem).

Top-5 rekomendasi untuk user dengan ID 1:
1. "The Godfather (1972)"
2. "Pulp Fiction (1994)"
3. "The Shawshank Redemption (1994)"
4. "Schindler's List (1993)"
5. "Forrest Gump (1994)"

Insight: Rekomendasi menunjukkan film-film klasik dan kritikal sukses, mengindikasikan bahwa user 1 mungkin memiliki preferensi terhadap film-film berkualitas tinggi dan berpengaruh.

## Evaluation

### Content-based Filtering

Metrik evaluasi: Precision@k

Formula:
Precision@k = (Jumlah rekomendasi yang relevan di top-k) / k

Untuk evaluasi, kita menganggap rekomendasi relevan jika genre film yang direkomendasikan memiliki setidaknya satu genre yang sama dengan film input.

Hasil evaluasi untuk "Toy Story (1995)" dengan k=5:
Precision@5 = 5/5 = 1.0 (100%)

Insight: Model content-based berhasil merekomendasikan film-film dengan genre yang relevan (animasi dan keluarga) untuk "Toy Story".

### Collaborative Filtering

Metrik evaluasi: RMSE (Root Mean Square Error) dan MAE (Mean Absolute Error)

Formula:
RMSE = √(Σ(predicted - actual)² / n)
MAE = Σ|predicted - actual| / n

Hasil evaluasi:
RMSE: 0.9406
MAE: 0.7457

Insight: 
- RMSE menunjukkan rata-rata kesalahan prediksi sekitar 0.94 poin rating (dalam skala 1-5).
- MAE menunjukkan rata-rata absolut kesalahan prediksi sekitar 0.75 poin rating.

Kedua nilai ini menunjukkan bahwa model cukup akurat dalam memprediksi rating, dengan rata-rata kesalahan kurang dari 1 poin rating.

## Kesimpulan

Dampak terhadap Business Understanding:

1. Problem Statement:
   - Kedua model berhasil memberikan rekomendasi film berdasarkan kemiripan konten dan pola peringkat pengguna.
   - Kinerja model dapat diukur menggunakan metrik yang sesuai (Precision@k, RMSE, MAE).

2. Goals:
   - Sistem rekomendasi berbasis konten berhasil dikembangkan dengan akurasi tinggi (Precision@5 = 100% untuk contoh yang diberikan).
   - Sistem rekomendasi kolaboratif berhasil dikembangkan dengan RMSE 0.9406 dan MAE 0.7457, menunjukkan prediksi yang cukup akurat.
   - Metrik evaluasi berhasil diterapkan dan memberikan insight tentang kinerja model.

3. Solution Statement:
   - Penggunaan TF-IDF dan cosine similarity terbukti efektif untuk rekomendasi berbasis konten.
   - Algoritma SVD berhasil diterapkan untuk rekomendasi kolaboratif dengan hasil yang memuaskan.
   - Evaluasi menggunakan Precision@k, RMSE, dan MAE memberikan pemahaman komprehensif tentang kinerja model.

Dampak bisnis:
- Peningkatan pengalaman pengguna: Dengan rekomendasi yang akurat, pengguna dapat menemukan film yang sesuai dengan preferensi mereka, meningkatkan kepuasan dan engagement.
- Potensi peningkatan pendapatan: Rekomendasi yang tepat dapat mendorong pengguna untuk menonton lebih banyak film, berpotensi meningkatkan pendapatan platform streaming atau penjualan tiket bioskop.
- Insight pasar: Analisis preferensi pengguna dapat memberikan insight berharga untuk strategi konten dan pemasaran.


## Referensi

[1] Gomez-Uribe, C. A., & Hunt, N. (2015). The Netflix recommender system: Algorithms, business value, and innovation. ACM Transactions on Management Information Systems, 6(4), 1-19.